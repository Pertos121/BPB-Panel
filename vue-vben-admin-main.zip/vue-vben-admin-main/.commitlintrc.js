export { default } from '@vben/commitlint-config';
