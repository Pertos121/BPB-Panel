import './default.css';
import './dark.css';

export {};
