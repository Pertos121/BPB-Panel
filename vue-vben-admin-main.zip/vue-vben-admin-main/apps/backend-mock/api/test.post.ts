export default defineEventHandler(() => 'Test post handler');
