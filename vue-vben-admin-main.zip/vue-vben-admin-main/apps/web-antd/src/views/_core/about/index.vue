<script lang="ts" setup>
import { About } from '@vben/common-ui';

defineOptions({ name: 'About' });
</script>

<template>
  <About />
</template>
