export { default } from '@vben/tailwind-config/postcss';
