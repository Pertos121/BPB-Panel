# 定制开发

我们提供基于 Vben Admin 的技术支持服务及定制开发，基本需求我们都可以满足。

详细需求可添加作者了解，并注明来意：

- 通过邮箱联系开发者： [ann.vben@gmail.com](mailto:ann.vben@gmail.com)
- 通过微信联系开发者：

 <img src="https://unpkg.com/@vbenjs/static-source@0.1.7/source/wechat.jpg" style="width: 300px;"/>

我们会在第一时间回复您，定制费用根据需求而定。
