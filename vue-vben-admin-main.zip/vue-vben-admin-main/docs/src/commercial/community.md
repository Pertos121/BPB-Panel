# 社区交流

社区交流群主要是为了方便大家交流，提问，解答问题，分享经验等。偏自助方式，如果你有问题，可以通过以下方式加入社区交流群：

- [QQ频道](https://pd.qq.com/s/16p8lvvob)：推荐！！！主要提供问题解答，分享经验等。
- QQ群：[大群](https://qm.qq.com/q/MEmHoCLbG0)，[1群](https://qm.qq.com/q/YacMHPYAMu)、[2群](https://qm.qq.com/q/ajVKZvFICk)、[3群](https://qm.qq.com/q/36zdwThP2E)，[4群](https://qm.qq.com/q/sCzSlm3504)，主要使用者的交流群。
- [Discord](https://discord.com/invite/VU62jTecad): 主要提供问题解答，分享经验等。

::: tip

免费QQ群人数上限200，将会不定期清理。推荐加入QQ频道进行交流

:::

## 微信群

作者主要通过微信群提供帮助，如果你有问题，可以通过以下方式加入微信群。

通过微信联系作者，注明加群来意：

::: tip

因为微信群人数有限制，加微信群要求：

- 通过[赞助](../sponsor/personal.md)任意金额。
- 发送赞助`截图`，备注`加入微信群`即可。

:::

<img src="https://unpkg.com/@vbenjs/static-source@0.1.7/source/wechat.jpg" style="width: 300px;"/>
