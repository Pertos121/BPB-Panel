# 技术支持

## 问题反馈

在使用项目的过程中，如果遇到问题，你可以先详细阅读本文档，未找到解决方案时，可以通过以下方式获取技术支持：

- 通过 [GitHub Issues](https://github.com/vbenjs/vue-vben-admin/issues)
- 通过 [GitHub Discussions](https://github.com/vbenjs/vue-vben-admin/discussions)
