export type * from '@vben/plugins/vxe-table';

export const useVbenVxeGrid = () => {};
