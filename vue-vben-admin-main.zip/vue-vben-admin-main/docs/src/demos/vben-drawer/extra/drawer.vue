<script lang="ts" setup>
import { useVbenDrawer } from '@vben/common-ui';

const [Drawer] = useVbenDrawer();
</script>
<template>
  <Drawer title="组件抽离示例"> extra drawer content </Drawer>
</template>
