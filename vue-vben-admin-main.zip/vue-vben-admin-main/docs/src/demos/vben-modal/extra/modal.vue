<script lang="ts" setup>
import { useVbenModal } from '@vben/common-ui';

const [Modal] = useVbenModal();
</script>
<template>
  <Modal title="组件抽离示例"> extra modal content </Modal>
</template>
