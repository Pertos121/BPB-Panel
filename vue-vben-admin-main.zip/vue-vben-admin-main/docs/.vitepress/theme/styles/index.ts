import '@vben/styles';

import './variables.css';
import './base.css';
